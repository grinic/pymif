

test_path = "/g/mif/people/gritti/code/pymif_test_data/viventis_down"
output_path = "/g/mif/people/gritti/code/pymif_test_data/viventis_down_zarr"

if not os.path.exists(test_path):
    print(f"⚠️ Test path not found: {test_path}")
else:
    import napari
    reader = ViventisManager(test_path)
    data, meta = reader.read()

    print("✅ Metadata keys:", list(meta.keys()))
    print("✅ Axes:", meta["axes"])
    print("✅ Scales:", meta["scales"])
    print("✅ Channel names:", meta["channel_names"])
    
    print(meta)

    # print("✅ Data type:", type(data[0]))
    # print("✅ Data shape:", data.shape)
    # print("✅ Data chunks:", data.chunks)
    
    reader.build_pyramid(3,2)

    print("✅ Metadata keys:", list(meta.keys()))
    print("✅ Axes:", meta["axes"])
    print("✅ Scales:", meta["scales"])
    print("✅ Channel names:", meta["channel_names"])
    
    print(meta)

    reader.write("test.zarr")
    v = reader.visualize()
    
    napari.run()
    